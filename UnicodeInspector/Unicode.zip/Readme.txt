﻿
The files in this directory (or a zip file) contain underlying data that Unicode Inspector shows.  Some files are downloaded from the Official Unicode website (http://www.unicode.org).  Other files are created by the author.

When a new version of the Unicode Standard is published, its complementary data files are updated.  You can download the updated version and replacethe files in this directory with them, so that Unicode Inspector to show the updated information.  If you do, please download the five files from the same Unicode version.

The following files are from the Unicode website:

UnicodeData.txt
Unihan_IRGSources.txt
Unihan_OtherMappings.txt
Unihan_Variants.txt

Also, the file Unicode_ReadMe.txt is a copy of the file http://www.unicode.org/Public/UCD/latest/ucd/ReadMe.txt under a different name.  (Since the file you are reading now has the same name.)
